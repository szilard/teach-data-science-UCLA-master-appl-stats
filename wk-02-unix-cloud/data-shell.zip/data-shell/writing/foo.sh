#!/bin/sh

while `true`
do
	echo "i like Los Angeles"
	sleep 1
done
